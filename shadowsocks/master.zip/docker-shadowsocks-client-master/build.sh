docker build -t shadowsocks-client ./
